from django.urls import path
from music import views


app_name = 'music'

urlpatterns = [

    path('', views.index, name='index.html'),
    path('',views.information, name='index_information'),
    path('',views.listener, name='listener_information'),
    path('',views.artist, name='artist_information'), 
    path('',views.auction, name='auction_information'),


    path('copyright',views.copyright_ing,name='copyright_ing'),
    path('copyright',views.copyright_,name='copyright_end'),
    path('copyright',views.copyright_list,name='user_trade'),




]