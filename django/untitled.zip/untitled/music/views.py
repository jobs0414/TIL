from django.shortcuts import render, get_object_or_404, redirect  #내꺼
from django.http import HttpResponse
from music.models import Copyright
from django.views.generic.list import ListView

# Create your views here.


def copyright_list(request): 

    copyright= Copyright.objects.all().order_by('id')
    context ={} 
    context['copyright'] = copyright

    return render(request,'music/copyright_list.html',context)


def copyright_



def copyright_trade(request): 
    return render(request,'music/copyright_trade.html')
    

def index(request): 
    return render(request,'music/index.html')

def information(request): 
    return render(request,'index_information.html')


def listener(request): 
    return render(request,'listener_information.html')

def artist(request): 
    return render(request,'artist_information.html') 

def auction(request): 
    return render(request,'auction_information.html')

