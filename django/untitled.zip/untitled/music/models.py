from django.db import models

# Create your models here.

class Copyright(models.Model): 
    artist = models.CharField('아티스트',max_length=100)
    title = models.CharField('제목',max_length=50)
    images = models.BinaryField('앨범이미지', blank=True)

    def __str__(self): 
        return self.name 

class Index(models.Model): 
    pass 

