from django.apps import AppConfig


class StreamingConfig(AppConfig):
    name = 'streaming'
