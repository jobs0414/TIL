;(function(Musicoin) {

	'use strict';

	Musicoin.lib = function() {

		this.VERSION = '0.0.1';

		this.appVersion = (navigator.appVersion || '').toLowerCase();
		this.userAgent = (navigator.userAgent || '').toLowerCase();

		this.addAttr = function(element, prop, value) {
			if(element == null){
				return;
			}
			var getProp = [];
			var attr = element.getAttribute(prop);
			if(attr.indexOf(' ') != -1) {
				getProp = attr.split(' ');
			} else {
				getProp.push(attr);
			}
			if(prop == "style") {
				try {
					var ap = value.split(':')[0];
					var av = value.split(':')[1];
					var p;
					for(var i = 0; i < getProp.length; i++) {
						p = getProp[i].split(':')[0];
						if(ap == p) {
							getProp[i] = value;
							break;
						}
					}
				} catch(e) {}
			}
			var setProp = '';
			for(var i = 0; i < getProp.length; i++) {
				setProp += getProp[i] + ' ';
			}
			setProp = setProp + value;
			element.setAttribute(prop, setProp);
		};
		this.removeAttr = function(element, prop, value) {
			if(element == null){
				return;
			}
			var getProp = [];
			var attr = element.getAttribute(prop);
			if(attr.indexOf(' ') != -1){
				getProp = attr.split(' ');
			} else {
				getProp.push(attr);
			}
			var setProp = '';
			for(var i = 0; i < getProp.length; i++) {
				if(value != getProp[i]) {
					setProp += getProp[i] + ' ';
				}
			}
			element.setAttribute(prop, setProp.trim());
		};
		this.getAttr = function(element, prop) {
			var getProp = [];
			var attr = element.getAttribute(prop);
			if(attr == null) {
				attr = [];
			}
			if(attr.indexOf(" ") != -1) {
				getProp = attr.split(' ');
			} else {
				getProp.push(attr);
			}
			return getProp;
		};
		this.setAttr = function(element, attr) {
			for (var idx in attr) {
				if ((idx == 'styles' || idx == 'style') && typeof attr[idx] == 'object') {
					for (var prop in attr[idx]) {
						element.style[prop] = attr[idx][prop];
					}
				} else if (idx == 'html') {
					element.innerHTML = attr[idx];
				} else {
					element.setAttribute(idx, attr[idx]);
				}
			}
		};
		this.addEventListener = function(element, event, fn) {
			if(element == null){
				return false;
			}
			if(document.createEventObject){
				element.attachEvent('on' + event, fn);
			} else {
				if(event == 'resize'){
					element = window;
				}
				element.addEventListener(event, fn);
			}
		};
		this.removeEventListener = function(element, event, fn) {
			if(element == null){
				return false;
			}
			if(document.createEventObject) {
				element.detachEvent('on' + event, fn);
			} else {
				if(event == 'resize') {
					element = window;
				}
				element.removeEventListener(event, fn);
			}
		};
		this.getBrowserInfo = function() {
			return userAgent.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
		};
		this.isIE = function() {
			return (/msie/.test(userAgent) || /trident/.test(userAgent)) ? true : false;
		};
		this.isChrome = function() {
			return (/chrome/.test(userAgent)) ? true : false;
		};
		this.isSafari = function() {
			return (/safari/.test(userAgent)) ? true : false;
		};
		this.isFirefox = function() {
			return (/firefox/.test(userAgent)) ? true : false;
		};
		this.isBlackberry = function() {
			return (/blackberry/.test(userAgent) || /bb10/.test(userAgent)) ? true : false;
		};
		this.isWindow = function() {
			return /win/.test(appVersion);
		};
		this.isWindowPhone = function() {
			return this.isWindow() && /phone/.test(userAgent);
		};
		this.isMac = function() {
			return /mac/.test(appVersion);
		};
		this.isIphone = function() {
			return /iphone/.test(userAgent);
		};
		this.isIpad = function() {
			return /ipad/.test(userAgent);
		};
		this.isIpod = function() {
			return /ipod/.test(userAgent);
		};
		this.isIos = function() {
			return this.isIphone() || this.isIpad() || this.isIpod();
		};
		this.isAndroid = function() {
			return /android/.test(userAgent);
		};
		this.getSystemInfo = function() {
			var os = [
				{ name: 'Windows Phone', value: 'Windows Phone', version: 'OS' },
				{ name: 'Windows', value: 'Win', version: 'NT' },
				{ name: 'iPhone', value: 'iPhone', version: 'OS' },
				{ name: 'iPad', value: 'iPad', version: 'OS' },
				{ name: 'Kindle', value: 'Silk', version: 'Silk' },
				{ name: 'Android', value: 'Android', version: 'Android' },
				{ name: 'PlayBook', value: 'PlayBook', version: 'OS' },
				{ name: 'BlackBerry', value: 'BlackBerry', version: '/' },
				{ name: 'Macintosh', value: 'Mac', version: 'OS X' },
				{ name: 'Linux', value: 'Linux', version: 'rv' },
				{ name: 'Palm', value: 'Palm', version: 'PalmOS' }
			];
			var browser = [
				{ name: 'Chrome', value: 'Chrome', version: 'Chrome' },
				{ name: 'Firefox', value: 'Firefox', version: 'Firefox' },
				{ name: 'Safari', value: 'Safari', version: 'Version' },
				{ name: 'Internet Explorer', value: 'MSIE', version: 'MSIE' },
				{ name: 'Opera', value: 'Opera', version: 'Opera' },
				{ name: 'BlackBerry', value: 'CLDC', version: 'CLDC' },
				{ name: 'Mozilla', value: 'Mozilla', version: 'Mozilla' }
			];
			var header = [
				navigator.platform,
				navigator.userAgent,
				navigator.appVersion,
				navigator.vendor,
				window.opera
			];
			function matchItem(string, data) {
				var i = 0,
					j = 0,
					html = '',
					regex,
					regexv,
					match,
					matches,
					version;
				
				for (i = 0; i < data.length; i += 1) {
					regex = new RegExp(data[i].value, 'i');
					match = regex.test(string);
					if (match) {
						regexv = new RegExp(data[i].version + '[- /:;]([\\d._]+)', 'i');
						matches = string.match(regexv);
						version = '';
						if (matches) { if (matches[1]) { matches = matches[1]; } }
						if (matches) {
							matches = matches.split(/[._]+/);
							for (j = 0; j < matches.length; j += 1) {
								if (j === 0) {
									version += matches[j] + '.';
								} else {
									version += matches[j];
								}
							}
						} else {
							version = '0';
						}
						return {
							name: data[i].name,
							version: parseFloat(version)
						};
					}
				}
				return { name: 'unknown', version: 0 };
			}
			var agent = header.join(' ');
			var os = matchItem(agent, os);
			var browser = matchItem(agent, browser);
			return {
				os : os,
				browser : browser
			}
		};
		this.getSortAsc = function(data) {
			var data = data;
			data.sort(function (a, b) { 
				return a < b ? -1 : a > b ? 1 : 0;  
			});
			return data;
		};
		this.getSortDesc = function(arr) {
			var data = arr;
			data.sort(function (a, b) { 
				return a > b ? -1 : a < b ? 1 : 0;  
			});
			return data;
		};
		this.getMax = function(data) {
			var data = data.reduce( function (previous, current) { 
				return previous > current ? previous:current;
			});
			return data;
		};
		this.getMin = function(data) {
			var data = data.reduce( function (previous, current) { 
				return previous > current ? current:previous;
			});
			return data;
		};
		this.getCalculateStringLength = function(str,amount) {
			if (amount === undefined) {
				amount=-1;
			}
			var len = 0;
			var minA = [" ",",",".","'","(",")","!",":",";","-","I"];
			var check = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
			var checkE = /[A-Z]/;
			var checkS = /[a-z]/;
			var s;
			var returnStr="";
			for(var i = 0; i < str.length; i++){
				s = str.charAt(i);
				if(minA.indexOf(s) != -1){
					len += 0.35;
				} else {
					if(check.test(s) == true){
						len += 1;
					} else if(checkE.test(s) == true) {
						len += 0.5;
					} else if(checkS.test(s) == true){
						len += 0.5;
					} else {
						len += 0.4;
					}
				}
				if(len > amount && amount != -1) {
					return i-1;
				}
			}
			if(amount != -1){
				len = -1;
			}
			return len;
		};
		this.getStringEllipsis = function(str, amount, added) {
			if (added === undefined) {
				added='...';
			}
			var len = this.getCalculateStringWidth(str, amount);
			var returnStr='';
			if(len != -1) {
				returnStr = str.slice(0, len-1) + added;
			} else {
				returnStr = str;
			}
			return returnStr;
		};
		this.getUrlParam = function(url) {
			var urlObject = new Object;
			var pa = url.split('#');
			var urlStr = pa[0];
			if(pa) {
				urlObject.hash = pa[1];
			} else {
				urlObject.hash = null;
			}
			var userAgent = urlStr.split('?');
			var paramStr;
			if(userAgent.length < 2){
				urlObject.url = urlStr;
				return urlObject;
			} else {
				urlObject.url = userAgent[0];
				paramStr = userAgent[1];
				for(var x = 2; x < userAgent.length; ++x) {
					paramStr += '?' + userAgent[x];
				}
			}
			var param = {};
			var pa = paramStr.split('&');
			var sa;
			var value;
			for(var i = 0; i < pa.length; ++i){
				sa = pa[i].split('=');
				if(sa.length >= 2){
					value = sa[1];
					for(var x = 2; x < sa.length;++x){
						value += '=' + sa[x];
					}
					param[sa[0]] = value;
				}
				
			}	
			urlObject.param = param;
			return urlObject;
		};
		this.getCookie = function(str) {
			var strArg = str + '=';
			var nArgLen, nCookieLen, nEnd;
			var i = 0;
			var j = undefined;
			nArgLen = strArg.length;
			nCookieLen = document.cookie.length;
			if(nCookieLen > 0) {
				while(i < nCookieLen) {
					j = i + nArgLen;
					if(document.cookie.substring(i, j) == strArg) {
						nEnd = document.cookie.indexOf (';', j);
						if(nEnd == -1) {
							nEnd = document.cookie.length;
						}
						return unescape(document.cookie.substring(j, nEnd));
					}
					i = document.cookie.indexOf(' ', i) + 1;
					if (i == 0) break;
				}
			}
			return('');
		};
		this.setCookie = function(name, value, option) {
			var expires = null;
			var path = null;
			var domain = null;
			var secure= false;
			if (option!== undefined) { 
				var expires = (option.expires!== undefined)? option.expires : null;
				if (String(typeof expires) == 'number') {
					var days =  new Date();
					days.setDate(days.getDate() + expires);
					expires=days;
				}
				var path = (option.path !== undefined) ? option.path : null;
				var domain = (option.domain !== undefined) ? option.domain : null;
				var secure = (option.secure !== undefined) ? option.secure : false;
			}
			document.cookie = name + "=" + escape(String(value)) + ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) + ((path == null) ? "" : ("; path=" + path)) + ((domain == null) ? "" : ("; domain=" + domain)) + ((secure == true) ? "; secure" : "");
		};
		this.getRandomNumber = function(from, to) {
			return Math.floor((Math.random() * (to - from + 1)) + from);
		};
		this.toggleClass = function(element, className) {
			if(!element || !className) {
				return false;
			}
			var hasString = this.hasClass(element, className);
			if(hasString) {
				this.removeAttr(element, 'class', className);
			} else {
				this.addAttr(element, 'class', className);
			}
		};
		/*
		this.for = function(element, fn) {
			var i, len = element.length;
			for(i=0; i<len; i++) {
				fn(element[i]);
			}
		},
		*/
		this.getElementText = function(element, callback) {
			// http://jsfiddle.net/webx/ZhLep/
			var textNodes = '';
			var whitespace = /^\s*$/;
			var nodes = element.childNodes;
			if(element) {
				for(var i = 0, length = element.childNodes.length; i < length; i++) {
					var node = nodes[i];
					if (node.nodeName === "#text" && !(whitespace.test(node.nodeValue))) {
						textNodes = node.nodeValue;
						callback(textNodes);
					} else {
						this.getElementText(node, callback);
					}
				}
			}
		};
		this.hasClass = function(element, selector) {
			var className = " " + selector + " ";
			if ((" " + element.className + " ").replace(/[\n\t]/g, " ").indexOf(className) > -1) {
				return true;
			} else { 
				return false;
			}
		};
		this.getChildrens = function(element, selector) {
			// http://jsfiddle.net/tsgXs/
			var prop = '';
			var propValue = '';
			var isSelector = false;
			if(selector.indexOf('.') > -1) {
				prop = 'class';
				propValue = selector.substr(1, selector.length);
				isSelector = true;
			} else if(selector.indexOf('#') > -1) {
				prop = 'id';
				propValue = selector.substr(1, selector.length);
				isSelector = true;
			} else {
				prop = '';
				propValue = selector;
			}
			var value = '';
			var elements = [];
			if(element) {
				return getElement(element);
			}
			function getElement(parent) {
				var nodes = parent.childNodes;
				for(var i = 0, length = parent.childNodes.length; i < length; i++) {
					var node = nodes[i];
					if (node.nodeName != "#text") {
						value = (isSelector) ? Musicoin.lib.getAttr(node, prop)[0] : node.nodeName.toLowerCase();
						if(propValue == value) {
							elements.push(node);
						}
						getElement(node);
					}
				}
				return elements;
			}
		};
		this.getElementInnerWidth = function(element) {
			
		};
		this.getElementInnerHeight = function(element) {
			
		};
		this.getElementOuterWidth = function(element) {

		};
		this.getElementOuterHeight = function(element) {

		};
		this.numberWithCommas = function(value) {
			// http://stackoverflow.com/questions/2901102/how-to-print-a-number-with-commas-as-thousands-separators-in-javascript
			/*
			var parts = value.toString().split(".");
			parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			return parts.join(".");
			*/
			return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		};
		this.getScreenWidth = function() {
			return screen.width;
		}
		this.getScreenHeight = function() {
			return screen.height;
		}
		this.getOffsetLeft = function(element) {
			var offsetLeft = 0;
			do {
				if (!isNaN( element.offsetLeft )) {
					offsetLeft += element.offsetLeft;
				}
			} while ( element = element.offsetParent );
			return offsetLeft;
		};
		this.getOffsetTop = function(element) {
			var offsetTop = 0;
			do {
				if (!isNaN( element.offsetTop )) {
					offsetTop += element.offsetTop;
				}
			} while ( element = element.offsetParent );
			return offsetTop;
		};
		this.getNextElement = function(element, filter) {
			var sibs = [];
			while (element = element.nextSibling) {
				if (element.nodeType === 3) continue; // text node
				if (!filter || filter(element)) sibs.push(element);
			}
			return sibs;
		};
		this.getParentNode = function (element, selector) {
			if(!element) {
				this.console('no element');
				return false;
			}
			// Element.matches() polyfill
			if (!Element.prototype.matches) {
				Element.prototype.matches =
					Element.prototype.matchesSelector ||
					Element.prototype.mozMatchesSelector ||
					Element.prototype.msMatchesSelector ||
					Element.prototype.oMatchesSelector ||
					Element.prototype.webkitMatchesSelector ||
					function(s) {
						var matches = (this.document || this.ownerDocument).querySelectorAll(s),
							i = matches.length;
						while (--i >= 0 && matches.item(i) !== this) {}
						return i > -1;
					};
			}
			for ( ; element && element !== document; element = element.parentNode ) {
				if ( element.matches( selector ) ) return element;
			}
			return null;
		};
		this.removeClass = function (element, className) {
			if(!element || !className) {
				return false;
			}
			if (element.classList) {
				element.classList.remove(className);
			} else {
				element.className = element.className.replace(new RegExp('\\b' + className + '\\b', 'g'), '');
			}
		}
	};

	var instantiate = function() {
		var musicoin = new Musicoin.lib();
		musicoin.Class = Musicoin.lib;
		return musicoin;
	};

	Musicoin.lib = instantiate();

}(window.Musicoin = window.Musicoin || {}));
