;(function(Musicoin) {

    'use strict';

    // FAQ
    var buttonQuestion = document.querySelectorAll('.list-faq .button-question');
    var buttonQuesttionIcon = document.querySelectorAll('.list-faq .button-question i');
    var answer = document.querySelectorAll('.list-faq .answer');
    for(var i=0, ii=buttonQuestion.length; i<ii; i++) {
        buttonQuestion[i].index = i;
        buttonQuestion[i].addEventListener('click', function(e) {
            e = e || window.event;
            var element = e.target? e.target: e.srcElement;
            var index = element.index;
            Musicoin.lib.toggleClass(element, 'is-open');
            if(Musicoin.lib.hasClass(element, 'is-open')) {
                Musicoin.lib.addAttr(answer[index], 'class', 'visible');
                Musicoin.lib.setAttr(buttonQuesttionIcon[index], { 'class' : 'fa fa-minus' });
            } else {
                Musicoin.lib.removeAttr(answer[index], 'class', 'visible');
                Musicoin.lib.setAttr(buttonQuesttionIcon[index], { 'class' : 'fa fa-plus' });
            }
        }, false);
    }

    // GNB
    var w = 0, h = 0;
    var nav = document.querySelector('.nav');
    var buttonNav = document.querySelector('.button-nav');
    var dimd = document.querySelector('.dimd');

	// Mobile
    window.addEventListener('resize', setResize, false);
    window.addEventListener('load', setResize, false);
    function setResize() {
        w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
        if(w <= 768) {
            h  = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
            Musicoin.lib.setAttr(nav, { 'style' : 'height:'+h+'px' });
            Musicoin.lib.setAttr(buttonNav, { 'aria-hidden' : 'false' });
            Musicoin.lib.setAttr(dimd, { 'style' : 'height:'+h+'px' });
            Musicoin.lib.removeEventListener(buttonNav, 'click', offEvent);
            Musicoin.lib.addEventListener(buttonNav, 'click', offEvent);
        } else {
            Musicoin.lib.setAttr(nav, { 'style' : 'height:auto' });
            Musicoin.lib.setAttr(buttonNav, { 'aria-hidden' : 'true' });
            Musicoin.lib.removeAttr(nav, 'class', 'is-open');
            Musicoin.lib.removeAttr(dimd, 'class', 'is-open');
            Musicoin.lib.removeEventListener(buttonNav, 'click', offEvent);
        }
    }
    function offEvent() {
        Musicoin.lib.toggleClass(nav, 'is-open');
        Musicoin.lib.toggleClass(dimd, 'is-open');
    }

    // PC
    var navItems = nav.querySelectorAll('.link');
    var dropdown = nav.querySelectorAll('.level2');
    var selectedIndex = 0;

    function showDropdown(e) {
        hideDropdown();
        e = e || window.event;
        var element = e.target? e.target: e.srcElement;
        var next = Musicoin.lib.getNextElement(element)[0];
        var className = Musicoin.lib.getAttr(next, 'class').join(' ');
        Musicoin.lib.setAttr(element, {
            'class' : 'link is-dropdown selected'
        })
        Musicoin.lib.setAttr(next, {
            'class' : className + ' visible'
        })
    }
    function hideDropdown() {
        for(var i=0,ii=dropdown.length; i<ii; i++) {
            Musicoin.lib.setAttr(navItems[i], {
                'class' : 'link is-dropdown'
            })
            var className = Musicoin.lib.getAttr(dropdown[i], 'data-class').join(' ');
            Musicoin.lib.setAttr(dropdown[i], {
                'class' : className
            })
        }
    }
    function fixedNav() {
        hideDropdown();
        Musicoin.lib.addAttr(navItems[selectedIndex], 'class', 'selected');
        Musicoin.lib.addAttr(dropdown[selectedIndex], 'class', 'visible');
    }

    for(var i=0,ii=navItems.length; i<ii; i++) {
        var nextSibling = Musicoin.lib.getNextElement(navItems[i]);
        if(Musicoin.lib.getAttr(navItems[i], 'data-selected') == 'true') {
            selectedIndex = i;
        }
        if(nextSibling.length > 0) {
            navItems[i].addEventListener('mouseenter', showDropdown);
        }
    }
    nav.addEventListener('mouseleave', fixedNav);

}(window.Musicoin = window.Musicoin || {}));
