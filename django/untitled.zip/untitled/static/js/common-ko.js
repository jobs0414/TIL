var config = {
	messages: {
		ok: '확인',
		cancel: '취소',
		view_monthly: '월별보기',
		view_yearly: '연별보기',
	}
};
